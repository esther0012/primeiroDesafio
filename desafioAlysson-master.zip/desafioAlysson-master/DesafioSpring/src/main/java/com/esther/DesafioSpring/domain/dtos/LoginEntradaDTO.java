package com.esther.DesafioSpring.domain.dtos;

import lombok.Data;

@Data
public class LoginEntradaDTO {

    private String name;

    private String email;

    private String password;

}
