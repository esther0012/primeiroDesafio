export interface Inicial {
    id: number;
    name: string;
    email: string;
    password: string;
    permissao: number;
    descPermissao: string;
}
