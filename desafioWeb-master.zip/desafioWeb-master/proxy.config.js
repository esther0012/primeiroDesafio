const ProxyConfig = [
  {
    context: [''],
    target: 'http://localhost:8081/',
    secure: false,
    logLevel:'debug'
  }
];

module.exports =  ProxyConfig;
